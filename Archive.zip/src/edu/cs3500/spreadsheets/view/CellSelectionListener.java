package edu.cs3500.spreadsheets.view;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Class designed for representing a selected cell, uses a mouse listener to determine
 * which cell should be selected.
 */
public class CellSelectionListener implements MouseListener {

  private WorksheetGridPanel gridPanel;

  /**
   * constructor for the CellSelectionListener class.
   * @param gridPanel WorksheetGridPanel to assign to the class.
   */
  CellSelectionListener(WorksheetGridPanel gridPanel) {
    this.gridPanel = gridPanel;
  }

  /**
   * Invoked when the mouse button has been clicked (pressed and released) on a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseClicked(MouseEvent e) {
    int xPos = e.getX() / WorksheetCellPanel.CELL_WIDTH;
    int yPos = e.getY() / WorksheetCellPanel.CELL_HEIGHT;
    try {
      this.gridPanel.changeSelected(yPos,xPos);
    }
    catch (IllegalArgumentException iae) {
      // do not want the program to crash with out of bounds click. should do nothing.
    }
    this.gridPanel.revalidate();
    this.gridPanel.repaint();
  }

  /**
   * Invoked when a mouse button has been pressed on a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mousePressed(MouseEvent e) {
    // no event to take place.
  }

  /**
   * Invoked when a mouse button has been released on a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseReleased(MouseEvent e) {
    // no event to take place.
  }

  /**
   * Invoked when the mouse enters a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseEntered(MouseEvent e) {
    // no event to take place.
  }

  /**
   * Invoked when the mouse exits a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseExited(MouseEvent e) {
    // no event to take place.
  }
}
