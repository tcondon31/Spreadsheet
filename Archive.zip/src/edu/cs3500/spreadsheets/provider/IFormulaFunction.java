package edu.cs3500.spreadsheets.provider;

/**
 * Represents a function that is a formula {FormulaInterface}.
 */
public interface IFormulaFunction extends FormulaInterface {
  
}
